setwd("C:/Users/skron/OneDrive/Documents/R/sparseVARboot")

library(sparseVARboot)
library(parallel)

#### Sourcing scripts ####
source("DGP.R") # R-script that collects relevant DGPs
source("Simulation.R")

# oracle ------------------------------------------------------------------
n <- c(50, 100, 200, 500) # =T
N <- 20 #c(20, 40, 100, 200) 
# DGPs
type <- 2 #c(5, 0, 1:2) 
# Mean
mu <- 0
# Proportion
prop <- 1
# Simulations
sim <- 1000 # 500
# Bootstrap replications
B <- 199
# Confidence level
level <- c(0.9, 0.95, 0.99)
# Method
boot="VAR-oracle"

pars <- expand.grid(mean = mu, prop = prop, n = n, N = N, DGP = type)
parsnames <- paste0("(DGP ", pars$DGP, ", N = ", pars$N, ", n = ", pars$n, 
                    ", N_mu = ", ceiling(pars$prop * pars$N), ", mu = ", pars$mean, ")")
set.seed(12345)
out <- lapply(1:sim, function(j){
  simulate_boot_all_methods(pars=pars[4,], boot=boot, B=B, level=level, p = 0, l = 0, parallel_sims = FALSE)
})
rej<-0
for(i in 1:sim){
  rej<-rej+out[[i]]$reject[2]/sim
}
rej

# BIC ------------------------------------------------------------------
n <- c(50, 100, 200, 500) # =T
N <- 20 #c(20, 40, 100, 200) 
# DGPs
type <- 2 #c(5, 0, 1:2) 
# Mean
mu <- 0
# Proportion
prop <- 1
# Simulations
sim <- 1000 # 500
# Bootstrap replications
B <- 199
# Confidence level
level <- c(0.9, 0.95, 0.99)
# Method
boot="VAR-L1-unpen-own-BIC"

pars <- expand.grid(mean = mu, prop = prop, n = n, N = N, DGP = type)
parsnames <- paste0("(DGP ", pars$DGP, ", N = ", pars$N, ", n = ", pars$n, 
                    ", N_mu = ", ceiling(pars$prop * pars$N), ", mu = ", pars$mean, ")")
set.seed(23456)
out <- lapply(1:sim, function(j){
  simulate_boot_all_methods(pars=pars[4,], boot=boot, B=B, level=level, p = 0, l = 0, parallel_sims = FALSE)
})
rej<-0
for(i in 1:sim){
  rej<-rej+out[[i]]$reject[2]/sim
}
rej

# TF-1.1 ------------------------------------------------------------------
n <- c(50, 100, 200, 500) # =T
N <- 20 #c(20, 40, 100, 200) 
# DGPs
type <- 2 #c(5, 0, 1:2) 
# Mean
mu <- 0
# Proportion
prop <- 1
# Simulations
sim <- 100 # 500
# Bootstrap replications
B <- 199
# Confidence level
level <- c(0.9, 0.95, 0.99)
# Method
boot="VAR-L1-unpen-own-TF-11"

pars <- expand.grid(mean = mu, prop = prop, n = n, N = N, DGP = type)
parsnames <- paste0("(DGP ", pars$DGP, ", N = ", pars$N, ", n = ", pars$n, 
                    ", N_mu = ", ceiling(pars$prop * pars$N), ", mu = ", pars$mean, ")")
set.seed(34567)
out <- lapply(1:sim, function(j){
  simulate_boot_all_methods(pars=pars[4,], boot=boot, B=B, level=level, p = 0, l = 0, parallel_sims = FALSE)
})
rej<-0
for(i in 1:sim){
  rej<-rej+out[[i]]$reject[2]/sim
}
rej