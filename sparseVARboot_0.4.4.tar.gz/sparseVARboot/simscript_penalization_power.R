# Simulation Script
rm(list=ls())

library(sparseVARboot)
library(parallel)

#### Sourcing scripts ####
source("DGP.R") # R-script that collects relevant DGPs
source("Simulation.R")

# Sample sizes
n <- c(50, 100, 200, 500) 
N <- c(20, 40, 100, 200)
# DGPs
type <- c(1:2, 5, 0)
# Mean
mu <- c(0.2, 0.5, 1, 2)
# Proportion
prop <- c(0.1, 0.5, 1)
# Simulations
sim <- 500
# Bootstrap replications
B <- 199
# Confidence level
level <- c(0.9, 0.95, 0.99)
# Methods
boot = c("VAR-L1-pen", "VAR-L1-unpen-own-1", "VAR-L1-unpen-own-p")

# 1 BIC, 2 AIC
selection <- 1

pars <- expand.grid(mean = mu, prop = prop, n = n, N = N, DGP = type)
parsnames <- paste0("(DGP ", pars$DGP, ", N = ", pars$N, ", n = ", pars$n, 
                    ", N_mu = ", ceiling(pars$prop * pars$N), ", mu = ", pars$mean, ")")

reject <- array(dim = c(nrow(pars), length(boot), length(level)))
dimnames(reject) <- list(pars = parsnames, boot = boot, level = 1 - level)

tuning <- array(dim = c(nrow(pars), length(boot), sim))
dimnames(tuning) <- list(pars = parsnames, boot = boot, sim = 1:sim)

parallel_sims <- TRUE

if (parallel_sims) {
  cl <- parallel::makeCluster(parallelly::availableCores(omit = 2))
  parallel::clusterExport(cl, varlist = ls(globalenv()))
  parallel::clusterEvalQ(cl, library(sparseVARboot))
  parallel::clusterEvalQ(cl, source("DGP.R"))
  parallel::clusterEvalQ(cl, source("Simulation.R"))
  parallel::clusterSetRNGStream(cl, sample.int(2^20, size = 1))
}

for (i in 1:nrow(pars)) {
  parallel::clusterExport(cl, varlist = "i")
  if (parallel_sims) {
    out <- parallel::parLapply(cl, 1:sim, function(j){
      simulate_boot_penalization(pars[i, ], boot, B, level, p = 0, l = 0, selection = selection, parallel_sims = parallel_sims)
    })
  } else {
    out <- lapply(1:sim, function(j){
      simulate_boot_penalization(pars[i, ], boot, B, level, p = 0, l = 0, selection = selection, parallel_sims = parallel_sims)
    })
  }
  reject[i, , ] <- apply(sapply(out, function(x){x$reject}, simplify = "array"), 1:2, mean)
  tuning[i, , ] <- sapply(out, function(x){x$tuning}, simplify = "array")
  save(reject, tuning, file = "SimResults_penL1_power.RData")
}

if (parallel_sims) {
  parallel::stopCluster(cl)
}

# Print
reject[, , 2] # 5%
apply(tuning[, c(1, 3), ], 1:2, mean) # Mean tuning parameters


#### Make Tables ####
# DGPS
# 1: DGP_Krampe
# 2: DGP_Kock_A
# 5: DGP_Kock_D
# 0: DGP_FNETS

#### Generate Plots ####
# First/Second/Thrid page of pdf plots results for proportion 0.1/0.5/1
level <- 2 # 1 (10\%), 2 (5\%), 3 (1\%) nominal sizes
d <- 2# Select DGP 1, 2, 5, 0
pdf(file = paste0("Power_DGP_", d,".pdf"), width = 10, height = 8)
par(mfrow=c(4,4), mar = c(4,4,2,1))
for(i.n in 1:length(n)){
  for(j.N in 1:length(N)){
    plot(x = mu, y = reject[which(pars$prop==0.1 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 1], type = "b",
         xaxt= "n", xlab = "Means", ylab = "Power", main = paste("N=", n[i.n], "and", "n=", N[j.N]),
         lwd = 2, pch = 15, ylim = c(0,1))
    axis(side = 1, at = mu, labels = mu)
    lines(x = mu, y = reject[which(pars$prop==0.1 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 2],
          col  = "blue", lwd = 2, type = "b", pch = 16)
    lines(x = mu, y = reject[which(pars$prop==0.1 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 3],
          col  = "red", lwd = 2, type = "b", pch = 17)
    legend("topright", c("pen", "unpen.1", "unpen.p"), col = c("black", "blue", "red"),
           lty = rep(1, 3), lwd = rep(2, 3), pch = c(15:17), bty = "n")
  }
}

for(i.n in 1:length(n)){
  for(j.N in 1:length(N)){
    plot(x = mu, y = reject[which(pars$prop==0.5 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 1], type = "b",
         xaxt= "n", xlab = "Means", ylab = "Power", main = paste("N=", n[i.n], "and", "n=", N[j.N]),
         lwd = 2, pch = 15, ylim = c(0,1))
    axis(side = 1, at = mu, labels = mu)
    lines(x = mu, y = reject[which(pars$prop==0.5 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 2],
          col  = "blue", lwd = 2, type = "b", pch = 16)
    lines(x = mu, y = reject[which(pars$prop==0.5 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 3],
          col  = "red", lwd = 2, type = "b", pch = 17)
    legend("topright", c("pen", "unpen.1", "unpen.p"), col = c("black", "blue", "red"),
           lty = rep(1, 3), lwd = rep(2, 3), pch = c(15:17), bty = "n")
  }
}

for(i.n in 1:length(n)){
  for(j.N in 1:length(N)){
    plot(x = mu, y = reject[which(pars$prop==1 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 1], type = "b",
         xaxt= "n", xlab = "Means", ylab = "Power", main = paste("N=", n[i.n], "and", "n=", N[j.N]),
         lwd = 2, pch = 15, ylim = c(0,1))
    axis(side = 1, at = mu, labels = mu)
    lines(x = mu, y = reject[which(pars$prop==1 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 2],
          col  = "blue", lwd = 2, type = "b", pch = 16)
    lines(x = mu, y = reject[which(pars$prop==1 & pars$n== n[i.n] & pars$N ==N[j.N] & pars$DGP==d), , level][, 3],
          col  = "red", lwd = 2, type = "b", pch = 17)
    legend("bottomright", c("pen", "unpen.1", "unpen.p"), col = c("black", "blue", "red"),
           lty = rep(1, 3), lwd = rep(2, 3), pch = c(15:17), bty = "n")
  }
}
dev.off()


