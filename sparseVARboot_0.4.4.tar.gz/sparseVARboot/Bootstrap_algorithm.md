*$K$ is chosen as in Algorithm 2. `Varboot.cpp`, function `VAR_determine_p` line 140. On line 163, an AR model is fit for all lags and variables using the `VAR` function (line 100). This function doesn't include an intercept by default, since it is provided the demeaned data.*

1. Given the sample $\{\boldsymbol{x}_t\}_{t=1}^T$ , compute the statistic $Q=\max\limits_{1\leq j\leq N}\left\vert\frac{1}{\sqrt{T}}\sum\limits_{t=1}^T x_{j,t}\right\vert$.
	
	- *In `Varboot.cpp`, function `boot_means`: line 511 computes the absolute means of all series, then line 543 takes the largest one, saving it as under `out_boot.mean`.* 
	
	- *The output struct gets turned into a list by the wrapper function `boot_means_R`.*
	
	- *In `Simulation.R`, function `simulate_boot_all_methods`: line 140 compares the statistic to bootstrapped quantiles.*

2. Demean the data to obtain $\tilde{\boldsymbol{x}}_{t}=\boldsymbol{x}_t-\bar{\boldsymbol{x}}_t$.
	
	- *In `Varboot.cpp`, function `boot_means`: lines 459-463 demean the data, storing at as simply `x`. The original data is `x_with_means`.*

3. Let $\hat{\boldsymbol{A}}_1,\dots,\hat{\boldsymbol{A}}_K$ be the lasso estimates in model (1) for the demeaned data, where unobserved values of the lags are padded with zeroes, i.e. we let $\tilde{\boldsymbol{x}}_{t}=\boldsymbol{0}$ for $t<1$.
	
	- *`boot_means` calls the `sparseVAR` function (line 1131 in `sparseVAR.cpp`), giving it the full demeaned data, and `trim=false`.*
	
	- *In `sparseVAR`, line 1155, the regressor matrix `VAR_lags` is built using the function `lag_matrix` (line 454), which pads missing values with 0 when `trim=false`.*
		
		- *The output of `lag_matrix` has $T$ rows: the full matrix is passed to it, the container `lag_x` is the same size (initialized with all zeroes), and when `trim=false`, the whole container is output.*

4. Set $\hat{\boldsymbol{\epsilon}}_t=\tilde{\boldsymbol{x}}_t-\sum\limits_{k=1}^K\hat{\boldsymbol{A}}_k\tilde{\boldsymbol{x}}_{t-k}$ for $t=1,\dots,T$.
	
	- *The residuals come from `sparseVAR.cpp` lines 1185, 1187, or 1189, depending on the selection method. Stored in `out.resid` on line 1194.*
	
	- *The residual matrix is $N\times T$, matching the dimension of the input data. To see this, we check the functions `selectPI`(line 532), `selectTF`(line 1024), `selectIC`(line 1095):*
		
		- *`selectPI`: with lines 606, 614, 618,`resid` is taken from the output of the `HVAR` function (line 384), and there the output matches the input dimensions, see line 404.*
		
		- *`selectTF`: $N$ (called k in `sparseVAR` and `selectTF`) is passed to `selectTF` in the 5th argument. `out_resid` is $T\times N$ (line 1041), filled up col-by-col (line 1081), then output whole (line 1087).*
		
		- *`selectIC`: `resids` is a $T\times N\times$`nbr_lambdas`array (line 1104). Each slice is filled using the output of `HVAR`(line 1111, 1113) like in `selectPI`, and then one slice is output (line 1124).* 

5. For $b\in\{1,\dots,B\}$ do:
	
	- *This loop is done using `parallelFor` in `boot_means` on line 522 in `Varboot.cpp`, using the `boot_sample_VAR_SWB` struct defined on line 334. This then runs the loop on line 360 in parallel.* 
	
	6. Generate $\gamma_1,\dots,\gamma_T$ from a $N(0,1)$ distribution.
		- *The $\gamma$'s are all stored in the $T\times B$ matrix `z`, generated on line 520, and passed as the second argument on line 521.* 
	
	7. Set $\boldsymbol{\epsilon}_t^*=\hat{\boldsymbol{\epsilon}}_t\gamma_t$ for $t=1,\dots,T$.
		
		- *The $T\times N$ matrix of residuals `out.resid` is passed as the first argument to `SWB` (line 270 in `Varboot.cpp`), and $T\times 1$ columns of `z` are passed as the second argument.
		
		- *The residual matrix is called `e` and the column is called `z`, confusingly.*
		
		- *The bootstrap errors are then computed on line 274 and stored in `e_star`, which is also $T\times N$ (`repelem(z, 1, k)` makes a $T\times N$ matrix repeating `z` in columns, and `%` does element-wise multiplication).*
	
	8. Build $\boldsymbol{x}_t^*$ recursively as $\boldsymbol{x}_t^*=\sum\limits_{k=1}^K\hat{\boldsymbol{A}}_k\boldsymbol{x}_{t-k}^*+\boldsymbol{\epsilon}_t^*$ for $t=1,\dots, T$, letting $\boldsymbol{x}_t^*=0$ for $t<1$.
		
		- *`SWB` calls `gen_VAR` on line 275, passing `e_star` in the first argument, `init` in the third and `include_init=false` as the fourth. `init` is set inside the wrapper function `boot_means_R`on line 557, to a $1\times 1$ matrix of value 0.* 
		
		- *`gen_VAR` is on line 212 of `Varboot.cpp`. It makes the $(T+K)\times N$ matrix `y`. Given the value of `init` we always go to line 221 in the `if` statement, initializing the first $K$ rows of it as zeroes.*
		
		- *$t=1,\dots,T$ is covered by the loop on line 224.*
		
		- *The lags of $\tilde{\boldsymbol{x}_t}$ are stacked up into the row vector `lags_y` on line 225.* 
		
		- *$\boldsymbol{x}_t^*=0$ for $t<1$ is implemented by taking them from the first $K$ rows of `y` which were initialized to 0.*
		
		- *$\sum\limits_{k=1}^K\hat{\boldsymbol{A}}_k\tilde{\boldsymbol{x}}_{t-k}^*$ is implemented with the matrix multiplication `lags_y * ar`( $1\times NK~*~NK\times N$) on line 226.* 
		
		- *The fourth argument `include_init` was provided as `false`on, so the first $K$ rows of `y` (all zeroes) are trimmed off on line 229, and `gen_VAR` returns a $T\times N$ matrix, which is stored as `x_star` in `SWB`.*
		
		- *`SWB` then returns the last $T$ rows of it, in case we didn't already trim it in `gen_VAR`.* 
	
	9. Compute and store the statistic $Q^{*b}=\max\limits_{1\leq j\leq N}\left\vert\frac{1}{\sqrt{T}}\sum\limits_{t=1}^T x_{j,t}^*\right\vert$.
		
		- *All absolute means are stored into slices of`means_boot` on line 363 of `Varboot.cpp`, using the `sorted_means` function.*
		
		- *The maxima are then taken by extracting the first elements from each slice on line 540.*
