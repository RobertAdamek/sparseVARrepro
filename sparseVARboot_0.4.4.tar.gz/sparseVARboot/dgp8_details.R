# There seems to be an issue with the BIC in the Kock A dgp (2), specifically at N=100, T=100
# The size is basically 0 at that point, and power is also extremely low at that point

# Simulation Script
rm(list=ls())

library(sparseVARboot)
library(parallel)

#### Sourcing scripts ####
source("DGP.R") # R-script that collects relevant DGPs
source("Simulation.R")

library(tidyverse)
library(ggpubr)
heat<-function(mat, min_lim=0, max_lim=1, title_addon="", negative=FALSE, mid_lim=0, max_dot=FALSE, frontier=FALSE){
  dat <- t(as.matrix(mat))
  ## the matrix needs names
  names(dat) <- paste("X", 1:ncol(mat))
  
  ## convert to tibble, add row identifier, and shape "long"
  dat2 <-
    dat %>%
    as_tibble() %>%
    rownames_to_column("Var1") %>%
    pivot_longer(-Var1, names_to = "Var2", values_to = "value") %>%
    mutate(
      Var1 = factor(Var1, levels = 1:ncol(mat)),
      Var2 = factor(gsub("V", "", Var2), levels = 1:ncol(mat))
    )
  #> Warning: The `x` argument of `as_tibble.matrix()` must have unique column names if
  #> `.name_repair` is omitted as of tibble 2.0.0.
  #> ℹ Using compatibility `.name_repair`.
  
  p<-ggplot(dat2, aes(Var1, Var2)) +
    geom_tile(aes(fill = value)) +
    scale_y_discrete(limits=rev)
  #geom_text(aes(label = round(value, 1))) +
  if(negative){
    p<-p + scale_fill_gradient2(low = "darkblue", high = "darkred", mid="white", midpoint=0,  trans="pseudo_log") #transform=scales::transform_pseudo_log(sigma=0.1)
  }else{
    p<-p + scale_fill_gradient(low = "white", high = "black", limits=c(min_lim,max_lim), trans="pseudo_log") #, transform=scales::transform_pseudo_log(sigma=0.1)
  }
  if(max_dot){
    dat3<-tibble(Var1=1:ncol(mat), Var2=ncol(mat):1)
    for(k in 1:ncol(mat)){
      dat3$Var1[k]=which.max(abs(mat[k,]))
    }
    p<-p+geom_point(data=dat3, aes(x= Var1, y=Var2), color="darkorange", shape=19)
  }
  if(frontier){
    dat4<-tibble(Var1=1:ncol(mat), Var2=ncol(mat):1)
    for(k in 1:ncol(mat)){
      dat4$Var1[k]=max(which(mat[k,]!=0))
    }
    p<-p+geom_point(data=dat4, aes(x= Var1, y=Var2), color="darkorange", shape=1)
  }
  p<-p +labs(title=paste0(ncol(mat), " x ", ncol(mat), title_addon))+
    theme_void()+
    theme(legend.position = "none")+
    theme(axis.title.x=element_blank(),
          axis.text.x=element_blank(),
          axis.ticks.x=element_blank())+
    theme(axis.title.y=element_blank(),
          axis.text.y=element_blank(),
          axis.ticks.y=element_blank())
  return(p)
}
# Sample sizes
n <- c(50, 100, 200, 500) 
N <- 200 #c(20, 40, 100, 200)
# DGPs
type <- 8 #c(5, 0, 1:2)
# Mean
mu <- 0
# Proportion
prop <- 0.5
# Simulations
sim <- 49 # 500
# Bootstrap replications
B <- 199
# Confidence level
level <- c(0.9, 0.95, 0.99)
# Methods
# boot = c("VAR-L1-pen-BIC", "VAR-L1-unpen-own-1-BIC", "VAR-L1-unpen-own-BIC",
#          "VAR-L1-pen-PI-04", "VAR-L1-unpen-own-1-PI-04", "VAR-L1-unpen-own-PI-04",
#          "VAR-L1-pen-PI-08", "VAR-L1-unpen-own-1-PI-08", "VAR-L1-unpen-own-PI-08",
#          "MBB", "BWB")

#boot = c("VAR-L1-pen-BIC", "VAR-L1-unpen-own-BIC",
#         "VAR-L1-pen-PI-08", "VAR-L1-unpen-own-PI-08",
#         "MBB", "BWB")

#boot = c("VAR-L1-pen-BIC", "VAR-L1-unpen-own-BIC",
#         "VAR-L1-pen-TF-11", "VAR-L1-unpen-own-TF-11",
#         "MBB", "BWB")

#boot = c("VAR-L1-unpen-own-BIC", 
#         "VAR-L1-unpen-own-TF-11", "VAR-L1-unpen-own-TF-08", "VAR-L1-unpen-own-TF-04",
#         "MBB", "BWB")

boot = "VAR-L1-unpen-own-BIC"
# 1 BIC, 2 AIC
# selection <- 1

pars <- expand.grid(mean = mu, prop = prop, n = n, N = N, DGP = type)
parsnames <- paste0("(DGP ", pars$DGP, ", N = ", pars$N, ", n = ", pars$n, 
                    ", N_mu = ", ceiling(pars$prop * pars$N), ", mu = ", pars$mean, ")")
pars 

# -------------------------------------------------------------------------



test<-simulate_boot_all_methods(pars=pars[,], boot="VAR-L1-unpen-own-BIC", B=199, level=c(0.9, 0.95, 0.99), p = 0, l = 0, parallel_sims = FALSE)
#test<-simulate_boot_all_methods(pars=pars[4,], boot="VAR-L1-unpen-own-TF-11", B=199, level=c(0.9, 0.95, 0.99), p = 0, l = 0, parallel_sims = FALSE)
test$tuning
sum(test$coef_pre[[1]]!=test$coef_post[[1]])

heat(mat= test$coef_pre[[1]][1:N,1:N], negative=TRUE)
if(test$tuning>1){
  heat(mat= test$coef_pre[[1]][N+1:N,1:N], negative=TRUE)
}

test$lambda
test$lambdas
which(test$lambdas[[1]]==test$lambda)


# -------------------------------------------------------------------------

if(Sys.info()[7]=="skron"){
  save_folder<-"C:/Users/skron/OneDrive/Desktop/bootstrap_results/grendel results/"
}else{
  save_folder<-"C:/Users/au720495/OneDrive/Desktop/bootstrap_results/grendel results/"
}
# -------------------------------------------------------------------------

set.seed(8)
out <- lapply(1:sim, function(j){
  simulate_boot_all_methods(pars=pars[4,], boot="VAR-L1-unpen-own-BIC", B=199, level=c(0.9, 0.95, 0.99), p = 0, l = 0, parallel_sims = FALSE)
})

chosen_lambdas<-rep(sim, 0)
lambda_positions<-rep(sim, 0)
p<-list()
for(i in 1:sim){
  chosen_lambdas[i]<-out[[i]]$lambda
  lambda_positions[i]<-which(out[[i]]$lambdas[[1]]==out[[i]]$lambda)
  p[[i]]<-heat(mat= t(out[[i]]$coef_pre[[1]][1:N,1:N]), negative=TRUE)+labs(title=paste0(round(out[[i]]$lambda, digits=3)," (", which(out[[i]]$lambdas[[1]]==out[[i]]$lambda), ")"))
}
comb<-ggarrange(plotlist=p, nrow=sqrt(sim), ncol=sqrt(sim))
comb2<-annotate_figure(comb, top=text_grob(paste0("DGP 8, N=20, T=500: lambda (grid position)"), face="bold"))
ggsave(paste0(save_folder,"inspection_dgp8_N200_T500.pdf"), plot=comb2, width=20, height=20, units="cm")

png(file=paste0(save_folder,"inspection_dgp8_N200_T500_hist_lambdas.png"), width=500, height=500)
hist(chosen_lambdas, breaks=30)
dev.off()

png(file=paste0(save_folder,"/inspection_dgp8_N200_T500_hist_positions.png"), width=500, height=500)
hist(lambda_positions, breaks=1:11-0.5)
dev.off()
