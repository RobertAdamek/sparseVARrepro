# Simulation Script
rm(list=ls())

library(sparseVARboot)
library(parallel)

#### Sourcing scripts ####
source("DGP.R") # R-script that collects relevant DGPs
source("Simulation.R")

# Sample sizes
n <- c(50, 100, 200, 500) 
N <- c(20, 40, 100, 200)
# DGPs
type <- c(5, 0, 1:2)
# Mean
mu <- 0
# Proportion
prop <- 1
# Simulations
sim <- 10 # 500
# Bootstrap replications
B <- 199
# Confidence level
level <- c(0.9, 0.95, 0.99)
# Methods
# boot = c("VAR-L1-pen-BIC", "VAR-L1-unpen-own-1-BIC", "VAR-L1-unpen-own-BIC",
#          "VAR-L1-pen-PI-04", "VAR-L1-unpen-own-1-PI-04", "VAR-L1-unpen-own-PI-04",
#          "VAR-L1-pen-PI-08", "VAR-L1-unpen-own-1-PI-08", "VAR-L1-unpen-own-PI-08",
#          "MBB", "BWB")

#boot = c("VAR-L1-pen-BIC", "VAR-L1-unpen-own-BIC",
#         "VAR-L1-pen-PI-08", "VAR-L1-unpen-own-PI-08",
#         "MBB", "BWB")

#boot = c("VAR-L1-pen-BIC", "VAR-L1-unpen-own-BIC",
#         "VAR-L1-pen-TF-11", "VAR-L1-unpen-own-TF-11",
#         "MBB", "BWB")

boot = c("VAR-L1-unpen-own-BIC", 
         "VAR-L1-unpen-own-TF-11", "VAR-L1-unpen-own-TF-08", "VAR-L1-unpen-own-TF-04",
         "MBB", "BWB")
# 1 BIC, 2 AIC
# selection <- 1

pars <- expand.grid(mean = mu, prop = prop, n = n, N = N, DGP = type)
parsnames <- paste0("(DGP ", pars$DGP, ", N = ", pars$N, ", n = ", pars$n, 
                    ", N_mu = ", ceiling(pars$prop * pars$N), ", mu = ", pars$mean, ")")

reject <- array(dim = c(nrow(pars), length(boot), length(level)))
dimnames(reject) <- list(pars = parsnames, boot = boot, level = 1 - level)

tuning <- array(dim = c(nrow(pars), length(boot), sim))
dimnames(tuning) <- list(pars = parsnames, boot = boot, sim = 1:sim)

parallel_sims <- TRUE

if (parallel_sims) {
  cl <- parallel::makeCluster(parallelly::availableCores(omit = 2))
  parallel::clusterExport(cl, varlist = ls(globalenv()))
  parallel::clusterEvalQ(cl, library(sparseVARboot))
  parallel::clusterEvalQ(cl, source("DGP.R"))
  parallel::clusterEvalQ(cl, source("Simulation.R"))
  parallel::clusterSetRNGStream(cl, sample.int(2^20, size = 1))
}

for (i in 1:nrow(pars)) {
  parallel::clusterExport(cl, varlist = "i")
  if (parallel_sims) {
    out <- parallel::parLapply(cl, 1:sim, function(j){
      simulate_boot_all_methods(pars[i, ], boot, B, level, p = 0, l = 0, parallel_sims = parallel_sims)
    })
  } else {
    out <- lapply(1:sim, function(j){
      simulate_boot_all_methods(pars[i, ], boot, B, level, p = 0, l = 0, parallel_sims = parallel_sims)
    })
  }
  reject[i, , ] <- apply(sapply(out, function(x){x$reject}, simplify = "array"), 1:2, mean)
  tuning[i, , ] <- sapply(out, function(x){x$tuning}, simplify = "array")
  save(reject, tuning, file = "C:/Users/skron/Downloads/simulation dump/SimResults_all_methods_size.RData")
}

if (parallel_sims) {
  parallel::stopCluster(cl)
}

# Print
reject[, , 2] # 5%
apply(tuning[, c(1, 3), ], 1:2, mean) # Mean tuning parameters


# #### Make Tables ####
# # DGPS
# # 1: DGP_Krampe
# # 2: DGP_Kock_A
# # 5: DGP_Kock_D
# # 0: DGP_FNETS
# 
# d <- 1 # Select DGP 1, 2, 5, 0
# level <- 2 # 1 (10\%), 2 (5\%), 3 (1\%) nominal sizes
# BLOCK_DGP <- rbind(cbind(t(reject[which(pars$DGP==d), ,level][1:4, ]), t(reject[which(pars$DGP==d), ,level][5:8, ])),
#                    cbind(t(reject[which(pars$DGP==d), ,level][9:12, ]), t(reject[which(pars$DGP==d), ,level][13:16, ])))
# rownames(BLOCK_DGP) <- rep(c("pen", "unpen 1", "unpen p"), 2)
# library(xtable)
# xtable(BLOCK_DGP, digits = 2)